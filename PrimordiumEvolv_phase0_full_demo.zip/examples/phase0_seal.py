
"""MIT SEAL fine‑tune with replay mixing and W&B logging."""
import os, argparse, random, wandb, torch
from ray.rllib.algorithms import ppo
from seal.trainer import ContinualTrainer
from seal.algorithms import SEALPPO

ENV_ID = "Isaac-Lab-ArmReach-v0"

def random_env_config(seed: int):
    rng = random.Random(seed)
    return {
        "seed": seed,
        "randomization_params": {
            "gravity": rng.uniform(-9.91, -9.71),
            "joint_damping_scale": rng.uniform(0.8, 1.2),
            "latency_ms": rng.uniform(0.0, 1.0),
        },
    }

def build_base_algo(seed: int):
    cfg = (
        ppo.PPOConfig()
        .environment(env=ENV_ID, env_config=random_env_config(seed))
        .training(model={"fcnet_hiddens": [256, 256],
                         "fcnet_dropout": 0.1},
                  entropy_coeff=0.01,
                  entropy_coeff_schedule=[[0,0.01],[200000,0.0]])
        .rollouts(num_rollout_workers=0)
        .framework("torch")
    )
    return cfg.build()

def main(args):
    os.makedirs(args.outdir, exist_ok=True)
    wandb.init(project="primordium_phase0", name="seal_finetune", dir=args.outdir)
    # Build algo just to load weights / env geometry
    algo = build_base_algo(seed=0)
    algo.restore(args.checkpoint)
    policy_state = algo.get_policy().get_state()
    algo.stop()
    # Continual Trainer
    trainer = ContinualTrainer(
        env_id=ENV_ID,
        base_policy_state=policy_state,
        algo_cls=SEALPPO,
        total_steps=args.steps,
        replay_ratio=0.3,               # 30% old, 70% new
        make_env_config_fn=random_env_config, # keeps domain randomisation during fine‑tune
    )
    final_state, metrics = trainer.train()
    torch.save(final_state, os.path.join(args.outdir, "seal_tuned.pt"))
    wandb.log(metrics)
    wandb.finish()
    print("SEAL fine‑tune complete; weights saved to seal_tuned.pt")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--checkpoint", required=True,
                    help="Path to NAS best.pt checkpoint")
    ap.add_argument("--steps", type=int, default=5000,
                    help="Total environment steps for SEAL fine‑tune")
    ap.add_argument("--outdir", type=str, default="runs/seal")
    args = ap.parse_args()
    main(args)
