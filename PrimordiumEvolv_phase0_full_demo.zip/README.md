
# PrimordiumEvolv – Phase 0 Demo (Overfitting‑Resistant with SEAL)

Full runnable scripts for Phase 0 including MIT SEAL fine‑tune.
